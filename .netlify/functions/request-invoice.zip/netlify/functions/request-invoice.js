"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// netlify/lib/leads.js
var require_leads = __commonJS({
  "netlify/lib/leads.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    var SUPABASE_URL = process.env.SUPABASE_URL || "https://bjnpibxaxlgvlzeegwnm.supabase.co";
    var SUPABASE_ANON = process.env.SUPABASE_ANON_KEY || "sb_publishable_Nj15e9wDVGVjBANsOdcTbg_AyXa1UJD";
    var SITE_URL = process.env.SITE_URL || "https://www.mgcglobalconsulting.com";
    var PRICING_TTL_MS = 10 * 6e4;
    function clean(value, max = 200) {
      return typeof value === "string" ? value.replace(/[\r\n]+/g, " ").trim().slice(0, max) : "";
    }
    function validEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email || "");
    }
    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
    }
    function escapeSlack(value) {
      return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    function sha256(value) {
      return crypto.createHash("sha256").update(value).digest("hex");
    }
    function hasServiceRole2() {
      return Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY);
    }
    function keyHeaders(key) {
      return key.startsWith("eyJ") ? { apikey: key, Authorization: `Bearer ${key}` } : { apikey: key };
    }
    async function db2(path, { method = "GET", body, prefer } = {}) {
      const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!key) throw new Error("SUPABASE_SERVICE_ROLE_KEY not set");
      const headers = { ...keyHeaders(key), "Content-Type": "application/json" };
      if (prefer) headers.Prefer = prefer;
      const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { method, headers, body: body ? JSON.stringify(body) : void 0 });
      if (!res.ok) throw new Error(`Supabase ${method} ${path.split("?")[0]} ${res.status}: ${(await res.text()).slice(0, 200)}`);
      return res.status === 204 ? null : res.json();
    }
    var pricingCache = { at: 0, rows: [] };
    async function getServicePricing() {
      if (Date.now() - pricingCache.at < PRICING_TTL_MS && pricingCache.rows.length) return pricingCache.rows;
      try {
        const res = await fetch(
          `${SUPABASE_URL}/rest/v1/mgc_service_pricing?select=slug,name,category,offer_type,price_usd,price_note,summary&active=eq.true&order=sort_order`,
          { headers: keyHeaders(SUPABASE_ANON) }
        );
        if (!res.ok) throw new Error(`pricing ${res.status}`);
        const rows = await res.json();
        pricingCache = { at: Date.now(), rows: Array.isArray(rows) ? rows : [] };
      } catch (err) {
        console.error("Pricing lookup failed:", err.message);
      }
      return pricingCache.rows;
    }
    function pricingForPrompt(rows) {
      if (!rows.length) return "Pricing table unavailable right now. Do not quote prices; point the visitor to /services or a $169 strategy session at /book.";
      return rows.map((r) => `- ${clean(r.name, 80)} (${clean(r.category, 30)}, ${clean(r.offer_type || "project", 12)}): $${Number(r.price_usd).toLocaleString("en-US")} ${clean(r.price_note, 40)}. ${clean(r.summary, 200)}`).join("\n");
    }
    function welcomeEmailHtml(lead) {
      const first = escapeHtml((lead.name || "").split(" ")[0] || "there");
      const booked = lead.booking ? `<p style="margin:0 0 16px">Your ${escapeHtml(lead.booking.service || "strategy session")} is ${lead.booking.status === "confirmed" ? "confirmed" : "requested"} for <strong>${escapeHtml(lead.booking.label)}</strong>${lead.booking.status === "confirmed" ? ". A calendar invite is on its way." : ". We will confirm the time within one business day."}</p>` : `<p style="margin:0 0 16px">Thanks for reaching out about ${escapeHtml(lead.interest || "working with MGC")}. A member of the team will reply within one business day.</p>`;
      return `<!doctype html>
<html><body style="margin:0;background:#010C1A;padding:32px 16px;font-family:Outfit,Helvetica,Arial,sans-serif;color:#E6F1FA">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#06182E;border:1px solid rgba(0,212,255,.25);border-radius:14px">
    <tr><td style="padding:28px 28px 8px">
      <div style="font-family:'JetBrains Mono',Menlo,monospace;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#00D4FF">MGC Global Consulting</div>
      <h1 style="margin:10px 0 18px;font-family:Raleway,Helvetica,Arial,sans-serif;font-size:24px;line-height:1.25;color:#FFFFFF">Hi ${first}, we have your ${lead.booking ? "booking" : "inquiry"}.</h1>
      ${booked}
      <p style="margin:0 0 16px">In the meantime, you can review services and pricing or pick a time that suits you.</p>
      <p style="margin:0 0 24px">
        <a href="${SITE_URL}/services" style="display:inline-block;padding:12px 20px;border-radius:999px;background:#00D4FF;color:#010C1A;font-weight:700;text-decoration:none">View services</a>
        <a href="${SITE_URL}/book" style="display:inline-block;margin-left:8px;padding:12px 20px;border-radius:999px;border:1px solid #FFB347;color:#FFB347;font-weight:700;text-decoration:none">Book a session</a>
      </p>
    </td></tr>
    <tr><td style="padding:16px 28px 26px;border-top:1px solid rgba(255,255,255,.08);font-size:12px;color:#8BA3BC">
      You are receiving this because you contacted MGC Global Consulting at mgcglobalconsulting.com. Reply to this email to reach the team.
    </td></tr>
  </table>
</body></html>`;
    }
    async function sendWelcomeEmail(lead) {
      const key = process.env.RESEND_API_KEY;
      const from = process.env.LEAD_EMAIL_FROM;
      if (!key || !from) return { skipped: "RESEND_API_KEY or LEAD_EMAIL_FROM not set" };
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
          // Same lead never gets two welcome emails if a retry re-runs this.
          "Idempotency-Key": `mgc-lead-${lead.id || sha256(lead.email + (lead.booking?.start || ""))}`
        },
        body: JSON.stringify({
          from,
          to: [lead.email],
          reply_to: process.env.LEAD_EMAIL_REPLY_TO || void 0,
          subject: lead.booking ? `Your MGC session: ${lead.booking.label}` : "We received your message \u2014 MGC Global Consulting",
          html: welcomeEmailHtml(lead)
        })
      });
      if (!res.ok) throw new Error(`Resend ${res.status}: ${(await res.text()).slice(0, 200)}`);
      return res.json();
    }
    function leadBlocks(lead) {
      const field = (label, value) => ({ type: "mrkdwn", text: `*${label}:*
${escapeSlack(value || "\u2014")}` });
      const blocks = [
        { type: "header", text: { type: "plain_text", text: lead.booking ? "New booking" : "New TrueAssist lead" } },
        {
          type: "section",
          fields: [
            field("Name", lead.name),
            field("Email", lead.email),
            field("Company", lead.company),
            field("Interest", lead.booking ? `${lead.booking.service} \u2014 ${lead.booking.label}` : lead.interest),
            field("Phone", lead.phone),
            field("Source", lead.source)
          ]
        }
      ];
      if (lead.message) blocks.push({ type: "section", text: { type: "mrkdwn", text: `*Summary:*
${escapeSlack(lead.message.slice(0, 1500))}` } });
      blocks.push({ type: "context", elements: [{ type: "mrkdwn", text: `Received ${(/* @__PURE__ */ new Date()).toUTCString()}${lead.id ? ` \xB7 lead ${lead.id}` : ""}` }] });
      return blocks;
    }
    async function postLeadToSlack(lead) {
      const webhook = process.env.SLACK_WEBHOOK_URL;
      if (!webhook) return { skipped: "SLACK_WEBHOOK_URL not set" };
      const res = await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: `New lead: ${lead.name || lead.email}`, blocks: leadBlocks(lead) })
      });
      if (!res.ok) throw new Error(`Slack webhook ${res.status}`);
      return { ok: true };
    }
    async function slackApi(method, payload) {
      const token = process.env.SLACK_BOT_TOKEN;
      if (!token) throw new Error("SLACK_BOT_TOKEN not set");
      const res = await fetch(`https://slack.com/api/${method}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json; charset=utf-8" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!data.ok) throw new Error(`Slack ${method}: ${data.error}`);
      return data;
    }
    async function postToTelegram(text) {
      const token = process.env.TELEGRAM_BOT_TOKEN;
      const chatId = process.env.TELEGRAM_OWNER_CHAT_ID;
      if (!token || !chatId) return { skipped: "TELEGRAM_BOT_TOKEN or TELEGRAM_OWNER_CHAT_ID not set" };
      const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: chatId, text: String(text).slice(0, 4e3), disable_web_page_preview: true })
      });
      const data = await res.json().catch(() => ({}));
      if (!data.ok) throw new Error(`Telegram sendMessage: ${data.description || res.status}`);
      return { ok: true };
    }
    function telegramLeadText(lead) {
      const lines = [
        lead.booking ? "New booking" : "New TrueAssist lead",
        `Name: ${lead.name || "\u2014"}`,
        `Email: ${lead.email}`,
        lead.company && `Company: ${lead.company}`,
        `Interest: ${lead.booking ? `${lead.booking.service} \u2014 ${lead.booking.label}` : lead.interest || "\u2014"}`,
        lead.phone && `Phone: ${lead.phone}`,
        `Source: ${lead.source}`,
        lead.message && `Summary: ${lead.message.slice(0, 500)}`
      ].filter(Boolean);
      return lines.join("\n");
    }
    async function recordLead(input) {
      const lead = {
        name: clean(input.name, 120),
        email: clean(input.email, 254).toLowerCase(),
        company: clean(input.company, 120),
        phone: clean(input.phone, 40),
        interest: clean(input.interest, 200),
        message: typeof input.message === "string" ? input.message.trim().slice(0, 2e3) : "",
        source: clean(input.source, 60) || "trueassist",
        booking: input.booking || null
      };
      if (!validEmail(lead.email)) throw Object.assign(new Error("A valid email is required"), { status: 400 });
      try {
        const [row] = await db2("mgc_leads", {
          method: "POST",
          prefer: "return=representation",
          body: {
            name: lead.name || null,
            email: lead.email,
            company: lead.company || null,
            phone: lead.phone || null,
            interest: lead.booking ? `${lead.booking.service} (${lead.booking.label})` : lead.interest || null,
            message: lead.message || null,
            source: lead.source,
            chat_session_id: input.chatSessionId || null
          }
        });
        lead.id = row.id;
      } catch (err) {
        console.error("Lead insert failed:", err.message);
      }
      const [email, slack, telegram] = await Promise.allSettled([
        sendWelcomeEmail(lead),
        postLeadToSlack(lead),
        postToTelegram(telegramLeadText(lead))
      ]);
      if (email.status === "rejected") console.error("Welcome email failed:", email.reason.message);
      if (slack.status === "rejected") console.error("Slack lead card failed:", slack.reason.message);
      if (telegram.status === "rejected") console.error("Telegram lead message failed:", telegram.reason.message);
      const emailed = email.status === "fulfilled" && !email.value?.skipped;
      const notified = slack.status === "fulfilled" && !slack.value?.skipped;
      if (lead.id && (emailed || notified)) {
        const now = (/* @__PURE__ */ new Date()).toISOString();
        await db2(`mgc_leads?id=eq.${lead.id}`, {
          method: "PATCH",
          body: { ...emailed && { email_sent_at: now }, ...notified && { slack_notified_at: now } }
        }).catch((err) => console.error("Lead status update failed:", err.message));
      }
      return { id: lead.id || null, stored: Boolean(lead.id), emailed, slack_notified: notified };
    }
    module2.exports = {
      SUPABASE_URL,
      SUPABASE_ANON,
      clean,
      validEmail,
      escapeSlack,
      sha256,
      hasServiceRole: hasServiceRole2,
      db: db2,
      getServicePricing,
      pricingForPrompt,
      sendWelcomeEmail,
      postLeadToSlack,
      slackApi,
      postToTelegram,
      recordLead
    };
  }
});

// netlify/functions/request-invoice.js
var CORS = {
  "Access-Control-Allow-Origin": "https://www.mgcglobalconsulting.com",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
var { db, hasServiceRole } = require_leads();
async function storedRefreshToken() {
  if (!hasServiceRole()) return null;
  const rows = await db("mgc_integration_tokens?provider=eq.quickbooks&select=refresh_token").catch(() => []);
  return rows?.[0]?.refresh_token || null;
}
async function refreshQBToken() {
  const creds = Buffer.from(
    `${process.env.QB_CLIENT_ID}:${process.env.QB_CLIENT_SECRET}`
  ).toString("base64");
  const current = await storedRefreshToken() || process.env.QB_REFRESH_TOKEN;
  if (!current) throw new Error("QuickBooks is not connected: no refresh token");
  const res = await fetch("https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer", {
    method: "POST",
    headers: {
      "Authorization": `Basic ${creds}`,
      "Content-Type": "application/x-www-form-urlencoded",
      "Accept": "application/json"
    },
    body: `grant_type=refresh_token&refresh_token=${encodeURIComponent(current)}`
  });
  const data = await res.json();
  if (!res.ok || !data.access_token) {
    throw new Error(`QuickBooks token refresh failed: ${data.error || res.status}`);
  }
  if (data.refresh_token && data.refresh_token !== current && hasServiceRole()) {
    await db("mgc_integration_tokens?on_conflict=provider", {
      method: "POST",
      prefer: "resolution=merge-duplicates,return=minimal",
      body: {
        provider: "quickbooks",
        refresh_token: data.refresh_token,
        expires_at: new Date(Date.now() + (data.x_refresh_token_expires_in || 0) * 1e3).toISOString(),
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }
    }).catch((err) => console.error("[request-invoice] Could not save new QuickBooks refresh token:", err.message));
  }
  return data.access_token;
}
async function notifySlack(body) {
  const webhook = process.env.SLACK_PAYMENTS_WEBHOOK;
  if (!webhook) return;
  await fetch(webhook, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      blocks: [
        { type: "section", text: { type: "mrkdwn", text: "*\u{1F4CB} New Invoice Request*" } },
        { type: "section", fields: [
          { type: "mrkdwn", text: `*Service:*
${body.service}` },
          { type: "mrkdwn", text: `*Amount:*
$${Number(body.amount).toLocaleString()}` },
          { type: "mrkdwn", text: `*Name:*
${body.customer_name}` },
          { type: "mrkdwn", text: `*Email:*
${body.customer_email}` },
          { type: "mrkdwn", text: `*Company:*
${body.company || "\u2014"}` },
          { type: "mrkdwn", text: `*Note:*
${body.note || "\u2014"}` }
        ] },
        { type: "context", elements: [{ type: "mrkdwn", text: `Received ${(/* @__PURE__ */ new Date()).toUTCString()}` }] }
      ]
    })
  });
}
async function createQBInvoice(token, body) {
  const BASE = `https://${process.env.QB_ENVIRONMENT === "sandbox" ? "sandbox-" : ""}quickbooks.api.intuit.com/v3/company/${process.env.QB_REALM_ID}`;
  const headers = {
    "Authorization": `Bearer ${token}`,
    "Accept": "application/json",
    "Content-Type": "application/json"
  };
  const safeEmail = (body.customer_email || "").replace(/'/g, "\\'");
  const qRes = await fetch(
    `${BASE}/query?query=SELECT * FROM Customer WHERE PrimaryEmailAddr='${safeEmail}'&minorversion=65`,
    { headers }
  );
  const qData = await qRes.json();
  let customerId = qData.QueryResponse?.Customer?.[0]?.Id;
  if (!customerId) {
    const cRes = await fetch(`${BASE}/customer?minorversion=65`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        DisplayName: body.company ? `${body.customer_name} (${body.company})` : body.customer_name,
        PrimaryEmailAddr: { Address: body.customer_email }
      })
    });
    const cData = await cRes.json();
    customerId = cData.Customer?.Id;
  }
  const dueDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString().slice(0, 10);
  const invRes = await fetch(`${BASE}/invoice?minorversion=65`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      CustomerRef: { value: customerId },
      DocNumber: `MGC-${Date.now()}`,
      DueDate: dueDate,
      AllowOnlineCreditCardPayment: true,
      AllowOnlineACHPayment: true,
      Line: [{
        Amount: body.amount,
        DetailType: "SalesItemLineDetail",
        SalesItemLineDetail: {
          ItemRef: { value: "1", name: "Services" },
          Qty: 1,
          UnitPrice: body.amount
        },
        Description: body.service
      }],
      CustomerMemo: {
        value: `Thank you for choosing MGC Global Consulting. This invoice covers: ${body.service}. Payment accepted via Credit Card or ACH. Questions? mark@mgcglobalconsulting.com`
      }
    })
  });
  const invData = await invRes.json();
  const invoiceId = invData.Invoice?.Id;
  if (invoiceId) {
    await fetch(
      `${BASE}/invoice/${invoiceId}/send?sendTo=${encodeURIComponent(body.customer_email)}&minorversion=65`,
      { method: "POST", headers: { ...headers, "Content-Type": "application/octet-stream" } }
    ).catch(console.error);
  }
  return invoiceId;
}
exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers: CORS, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers: CORS, body: "Method not allowed" };
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { service, amount, customer_name, customer_email } = body;
  if (!service || !amount || !customer_name || !customer_email) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "Missing required fields" }) };
  }
  const results = await Promise.allSettled([
    notifySlack(body),
    (async () => {
      if (!process.env.QB_CLIENT_ID) return null;
      const token = await refreshQBToken();
      return createQBInvoice(token, body);
    })()
  ]);
  const invoiceId = results[1].status === "fulfilled" ? results[1].value : null;
  console.log("[request-invoice] service=%s amount=%s invoiceId=%s", service, amount, invoiceId);
  return {
    statusCode: 200,
    headers: CORS,
    body: JSON.stringify({ received: true, invoice_id: invoiceId })
  };
};

"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// netlify/functions/slack-workflow-trigger.js
var require_slack_workflow_trigger = __commonJS({
  "netlify/functions/slack-workflow-trigger.js"(exports2) {
    "use strict";
    async function triggerNewLeadWorkflow({ name, email, company, service, message, source }) {
      const url = process.env.SLACK_NEW_LEAD_TRIGGER_URL;
      const channel = process.env.SLACK_INQUIRIES_CHANNEL_ID;
      if (!url || !channel) return { skipped: true };
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          channel,
          lead_name: name || "",
          lead_email: email || "",
          lead_company: company || "",
          lead_service: service || "",
          lead_message: message || "",
          lead_source: source || ""
        })
      });
      if (!res.ok) throw new Error(`Slack trigger ${res.status}: ${await res.text()}`);
      return { skipped: false };
    }
    async function triggerClientOnboardingWorkflow2({ name, email, company, phone, membershipTier, onboardingStatus }) {
      const url = process.env.SLACK_CLIENT_ONBOARDING_TRIGGER_URL;
      const channel = process.env.SLACK_CLIENTS_CHANNEL_ID;
      if (!url || !channel) return { skipped: true };
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          channel,
          client_name: name || "",
          client_email: email || "",
          client_company: company || "",
          client_phone: phone || "",
          membership_tier: membershipTier || "",
          onboarding_status: onboardingStatus || ""
        })
      });
      if (!res.ok) throw new Error(`Slack trigger ${res.status}: ${await res.text()}`);
      return { skipped: false };
    }
    exports2.triggerNewLeadWorkflow = triggerNewLeadWorkflow;
    exports2.triggerClientOnboardingWorkflow = triggerClientOnboardingWorkflow2;
  }
});

// netlify/functions/new-client-signup.js
var { triggerClientOnboardingWorkflow } = require_slack_workflow_trigger();
function notion(path, method = "GET", data) {
  return fetch(`https://api.notion.com/v1/${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${process.env.NOTION_API_KEY}`,
      "Notion-Version": "2022-06-28",
      "Content-Type": "application/json"
    },
    body: data ? JSON.stringify(data) : void 0
  }).then((r) => r.json());
}
async function findOrCreateCompany(companyName) {
  if (!companyName) return null;
  const search = await notion(
    `databases/${process.env.NOTION_COMPANIES_DATABASE_ID}/query`,
    "POST",
    { filter: { property: "Company Name", title: { equals: companyName } } }
  );
  if (search.results?.length) return search.results[0].id;
  const created = await notion("pages", "POST", {
    parent: { database_id: process.env.NOTION_COMPANIES_DATABASE_ID },
    properties: {
      "Company Name": { title: [{ text: { content: companyName } }] },
      "Account Status": { select: { name: "Lead" } }
    }
  });
  console.log("[Notion] Company created:", created.id);
  return created.id;
}
async function findOrCreateContact(profile, companyId) {
  const email = profile.email || "";
  const name = profile.full_name || email.split("@")[0] || "New Client";
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  if (email) {
    const search = await notion(
      `databases/${process.env.NOTION_CONTACTS_DATABASE_ID}/query`,
      "POST",
      { filter: { property: "Email", email: { equals: email } } }
    );
    if (search.results?.length) {
      console.log("[Notion] Contact already exists:", search.results[0].id);
      return search.results[0].id;
    }
  }
  const created = await notion("pages", "POST", {
    parent: { database_id: process.env.NOTION_CONTACTS_DATABASE_ID },
    properties: {
      "Full Name": { title: [{ text: { content: name } }] },
      "Email": { email: email || null },
      "Company": { relation: companyId ? [{ id: companyId }] : [] },
      "Status": { select: { name: "Lead" } },
      "Source": { select: { name: "Portal Signup" } },
      "First Contact Date": { date: { start: today } },
      "Last Contact Date": { date: { start: today } }
    }
  });
  console.log("[Notion] Contact created:", created.id, email);
  return created.id;
}
async function createLeadDeal(profile, companyId, contactId) {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const name = profile.full_name || profile.email?.split("@")[0] || "New Client";
  const created = await notion("pages", "POST", {
    parent: { database_id: process.env.NOTION_DEALS_DATABASE_ID },
    properties: {
      "Deal Name": { title: [{ text: { content: `${name} - Portal Signup` } }] },
      "Stage": { select: { name: "Lead" } },
      "Source": { select: { name: "Portal Signup" } },
      "Company": { relation: companyId ? [{ id: companyId }] : [] },
      "Contact": { relation: contactId ? [{ id: contactId }] : [] },
      "Close Date": { date: { start: today } }
    }
  });
  console.log("[Notion] Lead deal created:", created.id);
  return created.id;
}
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }
  const authHeader = event.headers["authorization"] || "";
  const expectedToken = process.env.SUPABASE_WEBHOOK_SECRET;
  if (expectedToken && authHeader !== `Bearer ${expectedToken}`) {
    console.error("[Signup] Unauthorized webhook call");
    return { statusCode: 401, body: "Unauthorized" };
  }
  let payload;
  try {
    payload = JSON.parse(event.body);
  } catch (err) {
    return { statusCode: 400, body: "Invalid JSON" };
  }
  if (payload.type !== "INSERT" || payload.table !== "mgc_client_profiles") {
    return { statusCode: 200, body: JSON.stringify({ received: true, ignored: true }) };
  }
  const profile = payload.record;
  console.log("[Signup] New client profile:", profile.id, profile.email);
  const [notionResult, slackResult] = await Promise.allSettled([
    (async () => {
      const companyId = await findOrCreateCompany(profile.company);
      const contactId = await findOrCreateContact(profile, companyId);
      await createLeadDeal(profile, companyId, contactId);
    })(),
    triggerClientOnboardingWorkflow({
      name: profile.full_name,
      email: profile.email,
      company: profile.company,
      phone: profile.phone,
      membershipTier: profile.membership_tier,
      onboardingStatus: profile.onboarding_status
    })
  ]);
  if (notionResult.status === "rejected") {
    console.error("[Signup] Notion sync failed:", notionResult.reason?.message);
  } else {
    console.log("[Signup] Notion sync complete for", profile.email);
  }
  if (slackResult.status === "rejected") {
    console.error("[Signup] Slack onboarding workflow trigger failed:", slackResult.reason?.message);
  }
  return { statusCode: 200, body: JSON.stringify({ received: true }) };
};

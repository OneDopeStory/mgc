"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// netlify/lib/leads.js
var require_leads = __commonJS({
  "netlify/lib/leads.js"(exports2, module2) {
    "use strict";
    var crypto = require("crypto");
    var SUPABASE_URL = process.env.SUPABASE_URL || "https://bjnpibxaxlgvlzeegwnm.supabase.co";
    var SUPABASE_ANON = process.env.SUPABASE_ANON_KEY || "sb_publishable_Nj15e9wDVGVjBANsOdcTbg_AyXa1UJD";
    var SITE_URL = process.env.SITE_URL || "https://www.mgcglobalconsulting.com";
    var PRICING_TTL_MS = 10 * 6e4;
    function clean(value, max = 200) {
      return typeof value === "string" ? value.replace(/[\r\n]+/g, " ").trim().slice(0, max) : "";
    }
    function validEmail(email) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email || "");
    }
    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
    }
    function escapeSlack2(value) {
      return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    function sha256(value) {
      return crypto.createHash("sha256").update(value).digest("hex");
    }
    function hasServiceRole() {
      return Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY);
    }
    function keyHeaders(key) {
      return key.startsWith("eyJ") ? { apikey: key, Authorization: `Bearer ${key}` } : { apikey: key };
    }
    async function db(path, { method = "GET", body, prefer } = {}) {
      const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!key) throw new Error("SUPABASE_SERVICE_ROLE_KEY not set");
      const headers = { ...keyHeaders(key), "Content-Type": "application/json" };
      if (prefer) headers.Prefer = prefer;
      const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { method, headers, body: body ? JSON.stringify(body) : void 0 });
      if (!res.ok) throw new Error(`Supabase ${method} ${path.split("?")[0]} ${res.status}: ${(await res.text()).slice(0, 200)}`);
      return res.status === 204 ? null : res.json();
    }
    var pricingCache = { at: 0, rows: [] };
    async function getServicePricing() {
      if (Date.now() - pricingCache.at < PRICING_TTL_MS && pricingCache.rows.length) return pricingCache.rows;
      try {
        const res = await fetch(
          `${SUPABASE_URL}/rest/v1/mgc_service_pricing?select=slug,name,category,offer_type,price_usd,price_note,summary&active=eq.true&order=sort_order`,
          { headers: keyHeaders(SUPABASE_ANON) }
        );
        if (!res.ok) throw new Error(`pricing ${res.status}`);
        const rows = await res.json();
        pricingCache = { at: Date.now(), rows: Array.isArray(rows) ? rows : [] };
      } catch (err) {
        console.error("Pricing lookup failed:", err.message);
      }
      return pricingCache.rows;
    }
    function pricingForPrompt(rows) {
      if (!rows.length) return "Pricing table unavailable right now. Do not quote prices; point the visitor to /services or a $169 strategy session at /book.";
      return rows.map((r) => `- ${clean(r.name, 80)} (${clean(r.category, 30)}, ${clean(r.offer_type || "project", 12)}): $${Number(r.price_usd).toLocaleString("en-US")} ${clean(r.price_note, 40)}. ${clean(r.summary, 200)}`).join("\n");
    }
    function welcomeEmailHtml(lead) {
      const first = escapeHtml((lead.name || "").split(" ")[0] || "there");
      const booked = lead.booking ? `<p style="margin:0 0 16px">Your ${escapeHtml(lead.booking.service || "strategy session")} is ${lead.booking.status === "confirmed" ? "confirmed" : "requested"} for <strong>${escapeHtml(lead.booking.label)}</strong>${lead.booking.status === "confirmed" ? ". A calendar invite is on its way." : ". We will confirm the time within one business day."}</p>` : `<p style="margin:0 0 16px">Thanks for reaching out about ${escapeHtml(lead.interest || "working with MGC")}. A member of the team will reply within one business day.</p>`;
      return `<!doctype html>
<html><body style="margin:0;background:#010C1A;padding:32px 16px;font-family:Outfit,Helvetica,Arial,sans-serif;color:#E6F1FA">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#06182E;border:1px solid rgba(0,212,255,.25);border-radius:14px">
    <tr><td style="padding:28px 28px 8px">
      <div style="font-family:'JetBrains Mono',Menlo,monospace;font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#00D4FF">MGC Global Consulting</div>
      <h1 style="margin:10px 0 18px;font-family:Raleway,Helvetica,Arial,sans-serif;font-size:24px;line-height:1.25;color:#FFFFFF">Hi ${first}, we have your ${lead.booking ? "booking" : "inquiry"}.</h1>
      ${booked}
      <p style="margin:0 0 16px">In the meantime, you can review services and pricing or pick a time that suits you.</p>
      <p style="margin:0 0 24px">
        <a href="${SITE_URL}/services" style="display:inline-block;padding:12px 20px;border-radius:999px;background:#00D4FF;color:#010C1A;font-weight:700;text-decoration:none">View services</a>
        <a href="${SITE_URL}/book" style="display:inline-block;margin-left:8px;padding:12px 20px;border-radius:999px;border:1px solid #FFB347;color:#FFB347;font-weight:700;text-decoration:none">Book a session</a>
      </p>
    </td></tr>
    <tr><td style="padding:16px 28px 26px;border-top:1px solid rgba(255,255,255,.08);font-size:12px;color:#8BA3BC">
      You are receiving this because you contacted MGC Global Consulting at mgcglobalconsulting.com. Reply to this email to reach the team.
    </td></tr>
  </table>
</body></html>`;
    }
    async function sendWelcomeEmail(lead) {
      const key = process.env.RESEND_API_KEY;
      const from = process.env.LEAD_EMAIL_FROM;
      if (!key || !from) return { skipped: "RESEND_API_KEY or LEAD_EMAIL_FROM not set" };
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
          // Same lead never gets two welcome emails if a retry re-runs this.
          "Idempotency-Key": `mgc-lead-${lead.id || sha256(lead.email + (lead.booking?.start || ""))}`
        },
        body: JSON.stringify({
          from,
          to: [lead.email],
          reply_to: process.env.LEAD_EMAIL_REPLY_TO || void 0,
          subject: lead.booking ? `Your MGC session: ${lead.booking.label}` : "We received your message \u2014 MGC Global Consulting",
          html: welcomeEmailHtml(lead)
        })
      });
      if (!res.ok) throw new Error(`Resend ${res.status}: ${(await res.text()).slice(0, 200)}`);
      return res.json();
    }
    function leadBlocks(lead) {
      const field = (label, value) => ({ type: "mrkdwn", text: `*${label}:*
${escapeSlack2(value || "\u2014")}` });
      const blocks = [
        { type: "header", text: { type: "plain_text", text: lead.booking ? "New booking" : "New TrueAssist lead" } },
        {
          type: "section",
          fields: [
            field("Name", lead.name),
            field("Email", lead.email),
            field("Company", lead.company),
            field("Interest", lead.booking ? `${lead.booking.service} \u2014 ${lead.booking.label}` : lead.interest),
            field("Phone", lead.phone),
            field("Source", lead.source)
          ]
        }
      ];
      if (lead.message) blocks.push({ type: "section", text: { type: "mrkdwn", text: `*Summary:*
${escapeSlack2(lead.message.slice(0, 1500))}` } });
      blocks.push({ type: "context", elements: [{ type: "mrkdwn", text: `Received ${(/* @__PURE__ */ new Date()).toUTCString()}${lead.id ? ` \xB7 lead ${lead.id}` : ""}` }] });
      return blocks;
    }
    async function postLeadToSlack(lead) {
      const webhook = process.env.SLACK_WEBHOOK_URL;
      if (!webhook) return { skipped: "SLACK_WEBHOOK_URL not set" };
      const res = await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: `New lead: ${lead.name || lead.email}`, blocks: leadBlocks(lead) })
      });
      if (!res.ok) throw new Error(`Slack webhook ${res.status}`);
      return { ok: true };
    }
    async function slackApi(method, payload) {
      const token = process.env.SLACK_BOT_TOKEN;
      if (!token) throw new Error("SLACK_BOT_TOKEN not set");
      const res = await fetch(`https://slack.com/api/${method}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json; charset=utf-8" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!data.ok) throw new Error(`Slack ${method}: ${data.error}`);
      return data;
    }
    async function recordLead(input) {
      const lead = {
        name: clean(input.name, 120),
        email: clean(input.email, 254).toLowerCase(),
        company: clean(input.company, 120),
        phone: clean(input.phone, 40),
        interest: clean(input.interest, 200),
        message: typeof input.message === "string" ? input.message.trim().slice(0, 2e3) : "",
        source: clean(input.source, 60) || "trueassist",
        booking: input.booking || null
      };
      if (!validEmail(lead.email)) throw Object.assign(new Error("A valid email is required"), { status: 400 });
      try {
        const [row] = await db("mgc_leads", {
          method: "POST",
          prefer: "return=representation",
          body: {
            name: lead.name || null,
            email: lead.email,
            company: lead.company || null,
            phone: lead.phone || null,
            interest: lead.booking ? `${lead.booking.service} (${lead.booking.label})` : lead.interest || null,
            message: lead.message || null,
            source: lead.source,
            chat_session_id: input.chatSessionId || null
          }
        });
        lead.id = row.id;
      } catch (err) {
        console.error("Lead insert failed:", err.message);
      }
      const [email, slack] = await Promise.allSettled([sendWelcomeEmail(lead), postLeadToSlack(lead)]);
      if (email.status === "rejected") console.error("Welcome email failed:", email.reason.message);
      if (slack.status === "rejected") console.error("Slack lead card failed:", slack.reason.message);
      const emailed = email.status === "fulfilled" && !email.value?.skipped;
      const notified = slack.status === "fulfilled" && !slack.value?.skipped;
      if (lead.id && (emailed || notified)) {
        const now = (/* @__PURE__ */ new Date()).toISOString();
        await db(`mgc_leads?id=eq.${lead.id}`, {
          method: "PATCH",
          body: { ...emailed && { email_sent_at: now }, ...notified && { slack_notified_at: now } }
        }).catch((err) => console.error("Lead status update failed:", err.message));
      }
      return { id: lead.id || null, stored: Boolean(lead.id), emailed, slack_notified: notified };
    }
    module2.exports = {
      SUPABASE_URL,
      SUPABASE_ANON,
      clean,
      validEmail,
      escapeSlack: escapeSlack2,
      sha256,
      hasServiceRole,
      db,
      getServicePricing,
      pricingForPrompt,
      sendWelcomeEmail,
      postLeadToSlack,
      slackApi,
      recordLead
    };
  }
});

// netlify/lib/slack-routing.js
var require_slack_routing = __commonJS({
  "netlify/lib/slack-routing.js"(exports2, module2) {
    "use strict";
    var { db, hasServiceRole } = require_leads();
    var AGENTS = {
      inquiries: "Intake Agent",
      clients: "Client Success Agent",
      billing: "Billing Agent",
      outreach: "Outreach Agent",
      approvals: "TrueAssist",
      ops: "Ops Monitor"
    };
    var CHANNEL_NAMES = {
      inquiries: "site-inquiries",
      clients: "clients",
      billing: "billing",
      outreach: "outreach",
      approvals: "approvals",
      ops: "ops-alerts"
    };
    function channelMap() {
      try {
        return JSON.parse(process.env.SLACK_CHANNEL_MAP || "{}") || {};
      } catch {
        console.error("[slack-routing] SLACK_CHANNEL_MAP is not valid JSON");
        return {};
      }
    }
    function channelFor(route) {
      const map = channelMap();
      return map[route] || map.inquiries || process.env.SLACK_INQUIRIES_CHANNEL_ID;
    }
    function routeForChannel(channelId) {
      const map = channelMap();
      const hit = Object.entries(map).find(([, id]) => id === channelId);
      if (hit) return hit[0];
      if (channelId && channelId === process.env.SLACK_INQUIRIES_CHANNEL_ID) return "inquiries";
      return null;
    }
    async function logSlackActivity({ agent, route, text, reply = false }) {
      if (!hasServiceRole()) return;
      const name = CHANNEL_NAMES[route] || route || "slack";
      await db("mgc_agent_events", {
        method: "POST",
        prefer: "return=minimal",
        body: {
          agent: String(agent || "Slack").slice(0, 120),
          event: reply ? "slack_reply" : "slack_message",
          detail: `#${name}: ${String(text || "").replace(/\s+/g, " ").trim().slice(0, 200)}`
        }
      }).catch((err) => console.error("[slack-routing] activity log failed:", err.message));
    }
    module2.exports = { AGENTS, CHANNEL_NAMES, channelFor, routeForChannel, logSlackActivity };
  }
});

// netlify/functions/slack-notify.js
var require_slack_notify = __commonJS({
  "netlify/functions/slack-notify.js"(exports2) {
    "use strict";
    var crypto = require("crypto");
    var { AGENTS, channelFor, logSlackActivity } = require_slack_routing();
    var TABLES = {
      mgc_leads: { route: "inquiries", title: "New lead", fields: ["name", "email", "company", "phone", "interest", "source", "message"] },
      mgc_bookings: { route: "inquiries", title: "New booking request", fields: ["name", "email", "company", "service", "service_line", "requested_date", "message"] },
      mgc_client_profiles: { route: "clients", title: "New client profile", fields: ["full_name", "email", "company", "phone", "industry"] },
      mgc_messages: { route: "clients", title: "New client message", fields: ["client_name", "company", "category", "subject", "message"] },
      mgc_uploads: { route: "clients", title: "New client upload", fields: ["client_name", "file_name", "file_size", "description"] },
      mgc_questionnaires: { route: "clients", title: "New business questionnaire", fields: ["client_name", "company", "q1", "q2", "q3", "q4", "q5"] }
    };
    var LABELS = {
      full_name: "Name",
      service_line: "Service line",
      requested_date: "Requested date",
      file_name: "File",
      file_size: "Size",
      q1: "Q1",
      q2: "Q2",
      q3: "Q3",
      q4: "Q4",
      q5: "Q5"
    };
    function label(key) {
      return LABELS[key] || key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, " ");
    }
    function escapeSlack2(text) {
      return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }
    function formatValue(key, value) {
      if (key === "file_size" && Number.isFinite(Number(value))) return `${(Number(value) / 1024).toFixed(0)} KB`;
      const text = typeof value === "object" ? JSON.stringify(value) : String(value);
      return escapeSlack2(text.length > 600 ? `${text.slice(0, 600)}\u2026` : text);
    }
    function secretMatches(given) {
      const expected = process.env.SLACK_NOTIFY_SECRET;
      if (!expected || typeof given !== "string") return false;
      const a = Buffer.from(given);
      const b = Buffer.from(expected);
      return a.length === b.length && crypto.timingSafeEqual(a, b);
    }
    function buildCard(table, record) {
      const { title, fields } = TABLES[table];
      const shown = fields.filter((k) => record[k] !== void 0 && record[k] !== null && record[k] !== "");
      const short = shown.filter((k) => !["message", "description", "q1", "q2", "q3", "q4", "q5"].includes(k));
      const long = shown.filter((k) => !short.includes(k));
      const blocks = [{ type: "section", text: { type: "mrkdwn", text: `*${title}*` } }];
      for (let i = 0; i < short.length; i += 10) {
        blocks.push({
          type: "section",
          fields: short.slice(i, i + 10).map((k) => ({ type: "mrkdwn", text: `*${label(k)}:*
${formatValue(k, record[k])}` }))
        });
      }
      for (const k of long) {
        blocks.push({ type: "section", text: { type: "mrkdwn", text: `*${label(k)}:*
${formatValue(k, record[k])}` } });
      }
      const when = record.created_at ? new Date(record.created_at) : /* @__PURE__ */ new Date();
      blocks.push({ type: "context", elements: [{ type: "mrkdwn", text: `${table} \xB7 ${when.toUTCString()}` }] });
      const who = record.name || record.full_name || record.client_name || record.email || "someone";
      return { text: `${title} from ${who}`, blocks, unfurl_links: false };
    }
    async function postToSlack2(message, route = "inquiries") {
      const token = process.env.SLACK_BOT_TOKEN;
      const channel = channelFor(route);
      if (token && channel) {
        const res2 = await fetch("https://slack.com/api/chat.postMessage", {
          method: "POST",
          headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json; charset=utf-8" },
          body: JSON.stringify({ channel, username: AGENTS[route] || AGENTS.inquiries, ...message })
        });
        const data = await res2.json().catch(() => ({}));
        if (!data.ok) throw new Error(`Slack error: ${data.error || res2.status}`);
        await logSlackActivity({ agent: AGENTS[route] || AGENTS.inquiries, route, text: message.text });
        return true;
      }
      const webhook = process.env.SLACK_INQUIRIES_WEBHOOK_URL || process.env.SLACK_WEBHOOK_URL;
      if (!webhook) return false;
      const res = await fetch(webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(message)
      });
      if (!res.ok) throw new Error(`Slack responded ${res.status}`);
      await logSlackActivity({ agent: AGENTS[route] || AGENTS.inquiries, route, text: message.text });
      return true;
    }
    exports2.handler = async (event) => {
      if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };
      if (!secretMatches(event.headers["x-webhook-secret"])) return { statusCode: 401, body: "Unauthorized" };
      let payload;
      try {
        payload = JSON.parse(event.body);
      } catch {
        return { statusCode: 400, body: "Invalid JSON" };
      }
      const { type, schema, table, record } = payload || {};
      if (type !== "INSERT" || schema !== "public" || !TABLES[table] || !record) {
        return { statusCode: 200, body: JSON.stringify({ skipped: true }) };
      }
      try {
        const posted = await postToSlack2(buildCard(table, record), TABLES[table].route);
        if (!posted) console.error("[Slack Notify] No Slack destination configured");
        return { statusCode: 200, body: JSON.stringify({ posted }) };
      } catch (err) {
        console.error("[Slack Notify] Post failed:", err.message);
        return { statusCode: 200, body: JSON.stringify({ posted: false }) };
      }
    };
    exports2.buildCard = buildCard;
    exports2.postToSlack = postToSlack2;
  }
});

// netlify/functions/lead-intake.js
var ALLOWED_ORIGIN = "https://www.mgcglobalconsulting.com";
function notion(path, method = "GET", data) {
  return fetch(`https://api.notion.com/v1/${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${process.env.NOTION_API_KEY}`,
      "Notion-Version": "2022-06-28",
      "Content-Type": "application/json"
    },
    body: data ? JSON.stringify(data) : void 0
  }).then((r) => r.json());
}
async function findOrCreateCompany(name) {
  if (!name) return null;
  const search = await notion(
    `databases/${process.env.NOTION_COMPANIES_DATABASE_ID}/query`,
    "POST",
    { filter: { property: "Company Name", title: { equals: name } } }
  );
  if (search.results?.length) return search.results[0].id;
  const created = await notion("pages", "POST", {
    parent: { database_id: process.env.NOTION_COMPANIES_DATABASE_ID },
    properties: {
      "Company Name": { title: [{ text: { content: name } }] },
      "Account Status": { select: { name: "Lead" } }
    }
  });
  console.log("[Lead Intake] Company created:", created.id);
  return created.id;
}
async function findOrUpdateContact(name, email, companyId) {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const search = await notion(
    `databases/${process.env.NOTION_CONTACTS_DATABASE_ID}/query`,
    "POST",
    { filter: { property: "Email", email: { equals: email } } }
  );
  if (search.results?.length) {
    const existing = search.results[0];
    await notion(`pages/${existing.id}`, "PATCH", {
      properties: {
        "Status": { select: { name: "Lead" } },
        "Last Contact Date": { date: { start: today } }
      }
    });
    console.log("[Lead Intake] Contact updated:", existing.id);
    return existing.id;
  }
  const created = await notion("pages", "POST", {
    parent: { database_id: process.env.NOTION_CONTACTS_DATABASE_ID },
    properties: {
      "Full Name": { title: [{ text: { content: name } }] },
      "Email": { email },
      "Company": { relation: companyId ? [{ id: companyId }] : [] },
      "Status": { select: { name: "Lead" } },
      "Source": { select: { name: "Website Form" } },
      "First Contact Date": { date: { start: today } },
      "Last Contact Date": { date: { start: today } }
    }
  });
  console.log("[Lead Intake] Contact created:", created.id);
  return created.id;
}
async function createDeal(name, service, message, requestedDate, companyId, contactId, extras) {
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const noteLines = [
    requestedDate && `Requested date: ${requestedDate}`,
    message && `Challenge: ${message}`,
    extras.visitorType && `Visitor type: ${extras.visitorType}`,
    extras.assignedSubAgent && `Assigned sub-agent: ${extras.assignedSubAgent}`,
    extras.recommendedNextStep && `Recommended next step: ${extras.recommendedNextStep}`,
    extras.readinessScore !== void 0 && `Readiness score: ${extras.readinessScore}/100 \u2014 ${extras.readinessCategory || ""}`,
    extras.timeline && `Timeline: ${extras.timeline}`,
    extras.budgetRange && `Budget range: ${extras.budgetRange}`,
    extras.source && `Source: ${extras.source}`
  ].filter(Boolean).join("\n");
  const created = await notion("pages", "POST", {
    parent: { database_id: process.env.NOTION_DEALS_DATABASE_ID },
    properties: {
      "Deal Name": { title: [{ text: { content: `${service} \u2014 ${name}` } }] },
      "Stage": { select: { name: "Lead" } },
      "Service Type": { select: { name: service } },
      "Source": { select: { name: extras.source || "Website Form" } },
      "Company": { relation: companyId ? [{ id: companyId }] : [] },
      "Contact": { relation: contactId ? [{ id: contactId }] : [] },
      "Created Date": { date: { start: today } },
      ...noteLines && { "Notes": { rich_text: [{ text: { content: noteLines } }] } }
    }
  });
  console.log("[Lead Intake] Deal created:", created.id);
}
function escapeSlack(text) {
  return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
var { postToSlack } = require_slack_notify();
async function notifySlack({ name, email, company, service, message, requestedDate, extras }) {
  const field = (label, value) => ({ type: "mrkdwn", text: `*${label}:*
${value ? escapeSlack(String(value).slice(0, 300)) : "\u2014"}` });
  await postToSlack({
    text: `New website inquiry from ${name}`,
    unfurl_links: false,
    blocks: [
      { type: "section", text: { type: "mrkdwn", text: "*New website inquiry*" } },
      { type: "section", fields: [
        field("Name", name),
        field("Email", email),
        field("Company", company),
        field("Service", service),
        field("Requested date", requestedDate),
        field("Source", extras.source),
        ...extras.readinessScore !== void 0 ? [field("Readiness", `${extras.readinessScore}/100 ${extras.readinessCategory}`)] : [],
        ...extras.timeline ? [field("Timeline", extras.timeline)] : [],
        ...extras.budgetRange ? [field("Budget", extras.budgetRange)] : []
      ] },
      ...message ? [{ type: "section", text: { type: "mrkdwn", text: `*Message:*
${escapeSlack(String(message).slice(0, 1500))}` } }] : [],
      { type: "context", elements: [{ type: "mrkdwn", text: `lead-intake \xB7 ${(/* @__PURE__ */ new Date()).toUTCString()}` }] }
    ]
  });
}
async function syncNotion(name, email, company, service, message, requestedDate, extras) {
  const companyId = await findOrCreateCompany(company || null);
  const contactId = await findOrUpdateContact(name, email, companyId);
  await createDeal(name, service, message, requestedDate, companyId, contactId, extras);
}
exports.handler = async (event) => {
  const corsHeaders = {
    "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }
  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, headers: corsHeaders, body: "Invalid JSON" };
  }
  const {
    name,
    email,
    company,
    service,
    message,
    requested_date,
    visitor_type,
    assigned_sub_agent,
    readiness_score,
    readiness_category,
    recommended_next_step,
    challenge,
    timeline,
    budget_range,
    source
  } = body;
  if (!name || !email || !service) {
    return { statusCode: 400, headers: corsHeaders, body: "Missing required fields" };
  }
  console.log("[Lead Intake] Processing submission from", email);
  const extras = {
    visitorType: visitor_type || "",
    assignedSubAgent: assigned_sub_agent || "",
    readinessScore: readiness_score,
    readinessCategory: readiness_category || "",
    recommendedNextStep: recommended_next_step || "",
    timeline: timeline || "",
    budgetRange: budget_range || "",
    source: source || "Website Form"
  };
  const [notionResult, slackResult] = await Promise.allSettled([
    syncNotion(name, email, company, service, challenge || message, requested_date, extras),
    notifySlack({ name, email, company, service, message: challenge || message, requestedDate: requested_date, extras })
  ]);
  if (notionResult.status === "fulfilled") console.log("[Lead Intake] Notion sync complete for", email);
  else console.error("[Lead Intake] Notion sync failed:", notionResult.reason?.message);
  if (slackResult.status === "rejected") console.error("[Lead Intake] Slack post failed:", slackResult.reason?.message);
  return {
    statusCode: 200,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
    body: JSON.stringify({ received: true })
  };
};
